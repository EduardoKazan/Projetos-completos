#pragma once

class LED {
public:
  void init();

  void on();

  void off();
};
